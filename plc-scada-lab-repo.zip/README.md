# PLC + SCADA lab appliance

A VM (OVA for VMware/VirtualBox, qcow2 for KVM/Proxmox) with:

* **PLC simulator** - Siemens S7, Rockwell EtherNet/IP, Schneider Modbus/UMAS, Mitsubishi MELSEC MC. Every PLC gets its own
  network namespace, MAC and IP (created from the web panel), so each looks like a separate device on the wire.
* **SCADA master + HMI** - polls/writes tags and sends start/stop/download to *any* of the four vendors with their native
  protocols (and plain Modbus devices). Own IP + MAC too. Tags, trends, alarms (HI/LO/comm loss), operator writes.
* **PLC-to-PLC links** - any vendor polls any other vendor, so east-west traffic crosses your vSwitch / SPAN port.

## Build
Push a tag (`git tag v1.0.0 && git push --tags`) or run **Actions -> Build PLC + SCADA lab appliance -> Run workflow**.
Output: `plc-scada-lab.ova`, `plc-scada-lab.qcow2`, `SHA256SUMS` (workflow artifact; attached to the Release on tags).
The job first runs `tests/smoke.py`, builds the image from the official Debian 12 cloud image, boots it in QEMU and
checks both web UIs answer before producing the OVA.

## Use
1. Import the OVA. 4 NICs: NIC1 = management (DHCP). NIC2-4 -> your OT vSwitch port groups, **no IP** on them.
   vSwitch port group: allow promiscuous mode, MAC address changes and forged transmits.
2. Console login `root` / `plcsim` (change it). `ip -4 a` shows the management IP.
3. `http://<mgmt-ip>:8080` PLC panel: **Add PLC** (vendor, model, IP, gateway, NIC). Pick **macvlan vepa** so PLC-to-PLC traffic
   leaves the VM (your switch must hairpin), or **dedicated adapter** (one VM NIC per PLC, always crosses the switch).
4. `http://<mgmt-ip>:8090` SCADA HMI: set the SCADA's own IP/NIC (bottom form), then **Import all simulated PLCs**
   (or add devices/tags by hand - real PLCs work too). Use Start/Stop/Write from the HMI.
5. PLC panel -> **Traffic between PLCs** to add vendor-to-vendor links.

Existing Debian/Ubuntu VM instead of the OVA: `sudo bash install.sh`.

## Honest limits
Protocol fidelity is "enough for discovery, polling, status and control", not full stacks (no TIA Portal / Studio 5000 /
GX Works engineering sessions). Real program transfer is not simulated: S7 has a download sequence; other vendors only
via the panel. Default credentials and the unauthenticated web panels are for isolated lab networks only.
