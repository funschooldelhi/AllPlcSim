#!/usr/bin/env bash
# Turn an existing Debian 12 / Ubuntu 22.04+ VM into the PLC + SCADA lab appliance (same result as the OVA).
set -e
[ "$(id -u)" = 0 ] || { echo "run as root"; exit 1; }
cd "$(dirname "$0")"
apt-get update
apt-get install -y python3 iproute2 isc-dhcp-client open-vm-tools openssh-server
install -d /opt/plcsim /etc/plcsim
install -m 755 plc_sim.py scada.py /opt/plcsim/
install -m 755 appliance/plcsim-net /usr/local/sbin/plcsim-net
install -m 644 appliance/plcsim.service appliance/plcsim-net.service /etc/systemd/system/
[ -f /etc/plcsim/plcs.json ] || install -m 644 appliance/plcs.json /etc/plcsim/plcs.json
[ -f /etc/plcsim/scada.json ] || install -m 644 appliance/scada.json /etc/plcsim/scada.json
systemctl daemon-reload
systemctl enable --now plcsim-net.service plcsim.service
echo "PLC panel: http://<mgmt-ip>:8080    SCADA HMI: http://<mgmt-ip>:8090"
