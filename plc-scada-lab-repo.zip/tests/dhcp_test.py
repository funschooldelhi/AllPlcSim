#!/usr/bin/env python3
"""DHCP client test against a tiny fake DHCP server on loopback (lease, option parsing, renewal, failure path)."""
import asyncio, os, socket, struct, sys, threading, time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import plc_sim as P

SPORT, CPORT = 16767, 16868
seen, cfg = [], {"answer": True}
MAGIC = b"\x63\x82\x53\x63"


def opts(data):
    o, i = {}, 240
    while i < len(data) and data[i] != 255:
        o[data[i]] = data[i + 2:i + 2 + data[i + 1]]
        i += 2 + data[i + 1]
    return o


def server():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", SPORT))
    while True:
        d, _ = s.recvfrom(1500)
        o = opts(d)
        t = o[53][0]
        seen.append((t, o.get(12, b"").decode(), 54 in o, o.get(50)))
        if not cfg["answer"]:
            continue
        rt = {1: 2, 3: 5}[t]
        r = struct.pack("!BBBBIHH4s4s4s4s", 2, 1, 6, 0, struct.unpack("!I", d[4:8])[0], 0, 0x8000, bytes(4),
                        socket.inet_aton("10.20.30.44"), socket.inet_aton("10.20.30.1"), bytes(4)) + d[28:44] + bytes(192) + MAGIC
        r += bytes([53, 1, rt, 54, 4]) + socket.inet_aton("10.20.30.1") + bytes([51, 4]) + struct.pack("!I", 2) + \
            bytes([1, 4, 255, 255, 255, 0, 3, 4]) + socket.inet_aton("10.20.30.1") + bytes([255])
        s.sendto(r, ("127.0.0.1", CPORT))


class Fake:                       # stands in for a PLC / SCADA node
    name, mac, ns, iface, parent, dhcp_task = "PLC-ONE", "00:0e:8c:11:22:33", None, "lo", "ens224", None
    ip = bind = gateway = None
    notes = []

    def note(self, m):
        self.notes.append(m)


fails = []


def check(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c:
        fails.append(m)


async def main():
    cmds = []
    P.ipcmd = lambda *a: cmds.append(a) or ""
    P.DHCP_MIN_RENEW = 0.3
    f = Fake()
    ip = await P.dhcp_lease(f, dest=("127.0.0.1", SPORT), cport=CPORT, bind_dev=False, timeout=1.0, tries=2)
    check(ip == "10.20.30.44" and f.bind == "10.20.30.44", "lease obtained: %s" % ip)
    check(f.prefix == 24 and f.gateway == "10.20.30.1", "mask /24 and gateway parsed")
    check(("-n", None, "addr", "add", "10.20.30.44/24", "dev", "lo") in cmds, "address configured in namespace")
    check(any(c[3] == "add" or c[2] == "route" for c in cmds if "route" in c), "default route configured")
    check(any(s[0] == 1 and s[1] == "PLC-ONE" for s in seen), "DISCOVER carries PLC name as hostname")
    check(any(s[0] == 3 and s[2] for s in seen), "REQUEST selects the offering server")
    await asyncio.sleep(1.8)
    renews = [s for s in seen if s[0] == 3 and not s[2] and s[3] == socket.inet_aton("10.20.30.44")]
    check(len(renews) >= 1, "background renewal re-requests the same IP (%d renewals)" % len(renews))
    P.teardown_ns(f)
    cfg["answer"] = False
    g = Fake()
    g.name = "PLC-TWO"
    try:
        await P.dhcp_lease(g, dest=("127.0.0.1", SPORT), cport=CPORT + 1, bind_dev=False, timeout=0.3, tries=2)
        check(False, "should fail when no DHCP server answers")
    except RuntimeError as e:
        check("no DHCP answer" in str(e), "clear error when no DHCP server answers")


threading.Thread(target=server, daemon=True).start()
time.sleep(0.3)
asyncio.run(main())
print("\n%d failure(s)" % len(fails))
sys.exit(1 if fails else 0)
