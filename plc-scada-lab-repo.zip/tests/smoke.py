#!/usr/bin/env python3
"""End-to-end smoke test: simulator (4 vendors) + SCADA master + PLC<->PLC links, all over real sockets on loopback."""
import json, os, subprocess, sys, tempfile, time, urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PP, SP = 18080, 18090
tmp = tempfile.mkdtemp()
cfg = {"plcs": [
    {"name": "S7", "vendor": "siemens", "bind": "127.0.0.11", "port": 10102, "sim": "idle"},
    {"name": "CLX", "vendor": "rockwell", "bind": "127.0.0.12", "port": 44818, "sim": "sine"},
    {"name": "SE", "vendor": "schneider", "bind": "127.0.0.13", "port": 10502, "sim": "tank"},
    {"name": "MIT", "vendor": "mitsubishi", "bind": "127.0.0.14", "port": 15007, "sim": "idle"}],
    "links": [{"from": "CLX", "to": "SE", "every": 1}, {"from": "S7", "to": "MIT", "every": 1},
              {"from": "SE", "to": "S7", "every": 1}, {"from": "MIT", "to": "CLX", "every": 1}]}
json.dump(cfg, open(tmp + "/plcs.json", "w"))
json.dump({"node": {}, "interval": 0.5, "devices": [], "tags": []}, open(tmp + "/scada.json", "w"))
proc = subprocess.Popen([sys.executable, ROOT + "/plc_sim.py", "--config", tmp + "/plcs.json", "--scada", tmp + "/scada.json",
                         "--panel-port", str(PP), "--scada-port", str(SP)], stdout=open(tmp + "/log", "w"), stderr=subprocess.STDOUT)
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


def get(port, path):
    return json.load(urllib.request.urlopen("http://127.0.0.1:%d%s" % (port, path), timeout=5))


def post(port, path, body=None):
    try:
        r = urllib.request.urlopen(urllib.request.Request("http://127.0.0.1:%d%s" % (port, path), data=json.dumps(body or {}).encode(), method="POST"), timeout=10)
        return json.load(r)
    except urllib.error.HTTPError as e:
        return json.load(e)


def wait(fn, t=15):
    end = time.time() + t
    while time.time() < end:
        try:
            if fn():
                return True
        except Exception:
            pass
        time.sleep(0.4)
    return False


try:
    check(wait(lambda: get(SP, "/api/state")), "SCADA HMI up")
    # tag Hi alarm on the SE tank level (D0 rises past 300)
    check(post(SP, "/api/import").get("ok"), "import simulated PLCs into SCADA")
    check(post(SP, "/api/tag", {"name": "SE.level_hi", "device": "SE", "addr": 0, "hi": 300}).get("ok"), "add tag with alarm limit")
    st = lambda: get(SP, "/api/state")
    check(wait(lambda: all(d["online"] for d in st()["devices"])), "all 4 vendors online in SCADA: %s" % [(d["name"], d["online"]) for d in st()["devices"]])
    check(wait(lambda: all(d["mode"] == "RUN" for d in st()["devices"])), "CPU mode read from all vendors = RUN")
    # write setpoint to each vendor and read it back through SCADA
    for i, name in enumerate(["S7", "CLX", "SE", "MIT"]):
        v = 100 + i * 11
        r = post(SP, "/api/write", {"tag": name + ".SP", "value": v})
        check(r.get("ok"), "write %s.SP=%d via native protocol (%s)" % (name, v, r.get("error", "")))
        check(wait(lambda: [t for t in st()["tags"] if t["name"] == name + ".SP"][0]["value"] == v), "read back %s.SP == %d" % (name, v))
    # process values are live for running sims
    a = [t for t in st()["tags"] if t["name"] == "CLX.D0"][0]["value"]
    check(a is not None, "CLX.D0 (sine) value present: %s" % a)
    # stop/start from SCADA on every vendor
    for name in ["S7", "CLX", "SE", "MIT"]:
        check(post(SP, "/api/cmd", {"device": name, "cmd": "stop"}).get("ok"), "STOP command -> %s" % name)
        check(wait(lambda: [d for d in st()["devices"] if d["name"] == name][0]["mode"] == "STOP"), "%s mode now STOP (confirmed by SCADA read-back)" % name)
        check(get(PP, "/api/state")["plcs"] and [p for p in get(PP, "/api/state")["plcs"] if p["name"] == name][0]["mode"] == "STOP", "%s simulator state = STOP" % name)
        check(post(SP, "/api/cmd", {"device": name, "cmd": "start"}).get("ok"), "START command -> %s" % name)
        check(wait(lambda: [d for d in st()["devices"] if d["name"] == name][0]["mode"] == "RUN"), "%s back to RUN" % name)
    # S7 program download from SCADA
    v0 = [p for p in get(PP, "/api/state")["plcs"] if p["name"] == "S7"][0]["version"]
    check(post(SP, "/api/cmd", {"device": "S7", "cmd": "download"}).get("ok"), "S7 download sequence")
    check(wait(lambda: [p for p in get(PP, "/api/state")["plcs"] if p["name"] == "S7"][0]["version"] == v0 + 1), "S7 program version incremented")
    # PLC <-> PLC traffic links healthy
    check(wait(lambda: all(l["ok"] for l in get(PP, "/api/state")["links"])), "PLC-to-PLC links all OK (vendor to vendor)")
    check(any(a["kind"] == "HI" for a in st()["alarms"]) or wait(lambda: any(a["kind"] == "HI" for a in st()["alarms"]), 25), "HI alarm raised from tank level")
finally:
    proc.terminate()
    proc.wait(10)
print("\n%d failure(s)" % len(fails))
if fails:
    print(open(tmp + "/log").read()[-3000:])
sys.exit(1 if fails else 0)
