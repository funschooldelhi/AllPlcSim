#!/usr/bin/env python3
"""
scada.py - lightweight multi-vendor SCADA master (polling + HMI + alarms + commands) for the PLC lab.
Runs inside plc_sim.py (`--scada /etc/plcsim/scada.json`). Pure stdlib.

Talks native protocols to ANY device, simulated or real:
  siemens    S7comm   ReadVar/WriteVar, SZL CPU status, PLC start/stop, download sequence
  rockwell   EtherNet/IP + CIP  Read/Write Tag, Identity state, Start/Stop
  schneider  Modbus TCP + UMAS  FC3/FC6/FC1, UMAS start/stop      (vendor "modbus" = plain Modbus device)
  mitsubishi MELSEC MC 3E       D-register read/write, SD203 CPU status, remote RUN/STOP

The SCADA has its own network identity (namespace + MAC + IP) so its polling crosses your vSwitch / SPAN port.
"""
import asyncio, collections, json, struct, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import plc_sim as P

DEFPORT = {"siemens": 102, "rockwell": 44818, "schneider": 502, "modbus": 502, "mitsubishi": 5007}


class Node:
    """The SCADA host's own identity on the OT network."""
    vendor = "scada"

    def __init__(self, cfg):
        self.name, self.ns = "SCADA", None
        self.set(cfg)

    def set(self, cfg):
        self.cfg = {k: v for k, v in cfg.items() if v not in (None, "")}
        self.dhcp = str(cfg.get("ip") or "").lower() == "dhcp" or bool(cfg.get("dhcp"))
        self.ip = None if self.dhcp else (cfg.get("ip") or None)
        self.iface, self.dhcp_task = "eth0", None
        self.prefix = int(cfg.get("prefix") or 24)
        self.gateway = cfg.get("gateway") or None
        self.vlan = int(cfg["vlan"]) if cfg.get("vlan") else None
        self.parent = cfg.get("parent")
        nm = cfg.get("netmode")
        self.netmode = "vepa" if nm in (None, "", "dedicated") else nm
        self.dedicated = nm == "dedicated"
        self.mac = cfg.get("mac") or P.make_mac("scada", "SCADA")
        self.bind = self.ip or "0.0.0.0"

    async def apply(self):
        P.teardown_ns(self)
        self.bind = self.ip or "0.0.0.0"
        if self.ip or self.dhcp:
            if not P.NETNS_OK:
                raise RuntimeError("SCADA IP/MAC needs Linux + root + iproute2")
            if not self.parent:
                raise RuntimeError("choose the VM adapter (NIC) for the SCADA")
            P.setup_ns(self)
            if self.dhcp:
                await P.dhcp_lease(self)


class Dev:
    def __init__(self, cfg, node):
        self.cfg, self.node = dict(cfg), node
        self.name, self.vendor, self.host = cfg["name"], cfg["vendor"].lower(), cfg["host"]
        self.port = int(cfg.get("port") or DEFPORT[self.vendor])
        self.proto = "modbus" if self.vendor in ("schneider", "modbus") else self.vendor
        self.r = self.w = None
        self.lock = asyncio.Lock()
        self.online, self.mode, self.err = False, "?", ""
        self.tid = self.pref = self.sess = 0

    # ---------- plumbing ----------
    async def rd(self, n):
        return await asyncio.wait_for(self.r.readexactly(n), 3)

    async def open(self):
        self.r, self.w = await P.ns_connect(self.node, self.host, self.port)
        if self.proto == "siemens":
            self.w.write(bytes.fromhex("0300001611e00000000100c0010ac1020100c2020102"))
            await self._tp()
            await self._s7(1, bytes.fromhex("f0000001000103c0"))
        elif self.proto == "rockwell":
            self.w.write(P.enip_frame(0x65, 0, b"scada000", struct.pack("<HH", 1, 0)))
            h = await self.rd(24)
            self.sess = struct.unpack("<I", h[4:8])[0]
            await self.rd(struct.unpack("<H", h[2:4])[0])

    async def close(self):
        if self.w:
            try:
                self.w.close()
            except Exception:
                pass
        self.r = self.w = None

    # ---------- Modbus / UMAS ----------
    async def _mb(self, pdu):
        self.tid = (self.tid + 1) & 0xFFFF
        self.w.write(struct.pack(">HHHB", self.tid, 0, len(pdu) + 1, 1) + pdu)
        h = await self.rd(7)
        body = await self.rd(struct.unpack(">H", h[4:6])[0] - 1)
        if body[0] & 0x80:
            raise IOError("modbus exception %d" % body[1])
        return body

    # ---------- S7 ----------
    async def _tp(self):
        h = await self.rd(4)
        return h + await self.rd(struct.unpack(">H", h[2:4])[0] - 4)

    async def _s7(self, ros, param, data=b""):
        self.pref = (self.pref + 1) & 0xFFFF
        self.w.write(P.tpkt(b"\x02\xf0\x80" + bytes([0x32, ros, 0, 0]) + struct.pack(">H", self.pref) +
                            struct.pack(">HH", len(param), len(data)) + param + data))
        s7 = (await self._tp())[7:]
        hl = 12 if s7[1] in (2, 3) else 10
        if hl == 12 and s7[10]:
            raise IOError("S7 error class 0x%02x code 0x%02x" % (s7[10], s7[11]))
        plen, dlen = struct.unpack(">HH", s7[6:10])
        return s7[hl:hl + plen], s7[hl + plen:hl + plen + dlen]

    @staticmethod
    def _s7item(addr, nbytes):
        return bytes([0x12, 0x0A, 0x10, 0x02]) + struct.pack(">HH", nbytes, 1) + bytes([0x84]) + (addr * 16).to_bytes(3, "big")

    # ---------- EtherNet/IP ----------
    async def _cip(self, cip):
        d = struct.pack("<IHH", 0, 0, 2) + bytes(4) + struct.pack("<HH", 0xB2, len(cip)) + cip
        self.w.write(P.enip_frame(0x6F, self.sess, b"scada000", d))
        h = await self.rd(24)
        pl = await self.rd(struct.unpack("<H", h[2:4])[0])
        r = pl[16:]
        if r[2]:
            raise IOError("CIP status 0x%02x" % r[2])
        return r[4 + r[3] * 2:]

    @staticmethod
    def _cippath(addr):
        p = bytes([0x91, 1, ord("D"), 0]) + (bytes([0x28, addr]) if addr < 256 else bytes([0x29, 0]) + struct.pack("<H", addr))
        return bytes([len(p) // 2]) + p

    # ---------- MELSEC MC ----------
    async def _mc(self, cmd, d=b"", sub=0):
        body = struct.pack("<HHH", 0x10, cmd, sub) + d
        self.w.write(b"\x50\x00\x00\xff\xff\x03\x00" + struct.pack("<H", len(body)) + body)
        h = await self.rd(9)
        b = await self.rd(struct.unpack("<H", h[7:9])[0])
        end = struct.unpack("<H", b[:2])[0]
        if end:
            raise IOError("MC end code 0x%04X" % end)
        return b[2:]

    # ---------- public operations ----------
    async def read_words(self, addr, n):
        if self.proto == "modbus":
            b = await self._mb(bytes([3]) + struct.pack(">HH", addr, n))
            return list(struct.unpack(">%dH" % n, b[2:2 + 2 * n]))
        if self.proto == "siemens":
            p, d = await self._s7(1, bytes([4, 1]) + self._s7item(addr, n * 2))
            if d[0] != 0xFF:
                raise IOError("S7 item error 0x%02x" % d[0])
            return list(struct.unpack(">%dH" % n, d[4:4 + 2 * n]))
        if self.proto == "rockwell":
            path = self._cippath(addr)
            b = await self._cip(bytes([0x4C]) + path + struct.pack("<H", n))
            return list(struct.unpack("<%dH" % n, b[2:2 + 2 * n]))
        b = await self._mc(0x0401, addr.to_bytes(3, "little") + bytes([0xA8]) + struct.pack("<H", n))
        return list(struct.unpack("<%dH" % n, b[:2 * n]))

    async def write_word(self, addr, v):
        v &= 0xFFFF
        if self.proto == "modbus":
            await self._mb(bytes([6]) + struct.pack(">HH", addr, v))
        elif self.proto == "siemens":
            p, d = await self._s7(1, bytes([5, 1]) + self._s7item(addr, 2), bytes([0, 4]) + struct.pack(">HH", 16, v))
            if d[0] != 0xFF:
                raise IOError("S7 write error 0x%02x" % d[0])
        elif self.proto == "rockwell":
            await self._cip(bytes([0x4D]) + self._cippath(addr) + struct.pack("<HHH", 0xC3, 1, v))
        else:
            await self._mc(0x1401, addr.to_bytes(3, "little") + bytes([0xA8]) + struct.pack("<HH", 1, v))

    async def read_mode(self):
        if self.proto == "modbus":
            b = await self._mb(bytes([1]) + struct.pack(">HH", 0, 1))
            return "RUN" if b[2] & 1 else "STOP"
        if self.proto == "siemens":
            p, d = await self._s7(7, bytes.fromhex("0001120411440100"), bytes.fromhex("ff090004") + struct.pack(">HH", 0x0424, 0))
            return "RUN" if d[12 + 3] == 0x08 else "STOP"
        if self.proto == "rockwell":
            path = bytes([0x20, 1, 0x24, 1, 0x30, 8])
            b = await self._cip(bytes([0x0E, len(path) // 2]) + path)
            return {3: "RUN", 5: "FAULT"}.get(b[0], "STOP")
        b = await self._mc(0x0401, (203).to_bytes(3, "little") + bytes([0xA9]) + struct.pack("<H", 1))
        return {0: "RUN", 3: "PAUSE"}.get(struct.unpack("<H", b[:2])[0], "STOP")

    async def command(self, cmd):
        if self.proto == "modbus":
            await self._mb(bytes([0x5A, 0, {"start": 0x40, "stop": 0x41}[cmd]]))
        elif self.proto == "siemens":
            if cmd == "download":
                for fn in (0x1A, 0x1B, 0x1C):
                    await self._s7(1, bytes([fn, 0, 0, 0, 0, 0, 0]))
            else:
                await self._s7(1, bytes([0x28 if cmd == "start" else 0x29, 0, 0, 0, 0, 0, 9]) + b"P_PROGRAM")
        elif self.proto == "rockwell":
            if cmd == "download":
                raise IOError("download not supported for this protocol in the simulator")
            await self._cip(bytes([0x06 if cmd == "start" else 0x07, 2, 0x20, 1, 0x24, 1]))
        else:
            if cmd == "download":
                raise IOError("download not supported for this protocol in the simulator")
            await self._mc(0x1001 if cmd == "start" else 0x1002, b"\x01\x00\x00\x00")


class Scada:
    def __init__(self, path):
        self.path, self.loop = path, None
        self.node = Node({})
        self.devs, self.tags, self.tasks = [], [], {}
        self.interval = 1.0
        self.alarms = collections.deque(maxlen=200)
        self.events = collections.deque(maxlen=100)
        self.aid = 0
        self.sim_url = "http://127.0.0.1:8080/api/state"

    # ---------- config ----------
    def ev(self, msg):
        line = "%s %s" % (time.strftime("%H:%M:%S"), msg)
        self.events.append(line)
        print("[SCADA] " + line, flush=True)

    def save(self):
        try:
            json.dump({"node": self.node.cfg, "interval": self.interval, "devices": [d.cfg for d in self.devs],
                       "tags": self.tags}, open(self.path, "w"), indent=2)
        except OSError as e:
            print("cannot save scada config:", e)

    async def start(self, bind, port):
        self.loop = asyncio.get_running_loop()
        cfg = {}
        try:
            cfg = json.load(open(self.path))
        except (OSError, ValueError):
            pass
        self.interval = float(cfg.get("interval", 1.0))
        self.node.set(cfg.get("node", {}))
        try:
            await self.node.apply()
            self.ev("node ready: %s" % (("%s mac %s" % (self.node.ip, self.node.mac)) if self.node.ip else "no IP set (legacy/host network)"))
        except Exception as e:
            self.ev("node network error: %s" % e)
        for d in cfg.get("devices", []):
            self.add_device(d, save=False)
        self.tags = cfg.get("tags", [])
        make_http(self, bind, port)

    def stop(self):
        P.teardown_ns(self.node)

    def add_device(self, cfg, save=True):
        cfg = dict(cfg)
        if not cfg.get("name") or not cfg.get("host"):
            return "name and host are required"
        if cfg.get("vendor", "").lower() not in DEFPORT:
            return "vendor must be one of: " + ", ".join(DEFPORT)
        if any(d.name == cfg["name"] for d in self.devs):
            return "device name exists"
        d = Dev(cfg, self.node)
        self.devs.append(d)
        self.tasks[d.name] = asyncio.ensure_future(self.poll(d))
        if save:
            self.save()
        return ""

    def del_device(self, name):
        t = self.tasks.pop(name, None)
        if t:
            t.cancel()
        dev = next((d for d in self.devs if d.name == name), None)
        if dev:
            asyncio.ensure_future(dev.close())
        self.devs = [d for d in self.devs if d.name != name]
        self.tags = [t for t in self.tags if t["device"] != name]
        self.save()
        return ""

    def add_tag(self, t):
        t = dict(t)
        if not t.get("name") or not any(d.name == t.get("device") for d in self.devs):
            return "tag needs a name and an existing device"
        if any(x["name"] == t["name"] for x in self.tags):
            return "tag name exists"
        t["addr"] = int(t.get("addr", 0))
        t["scale"] = float(t.get("scale") or 1)
        t["offset"] = float(t.get("offset") or 0)
        for k in ("hi", "lo"):
            t[k] = None if t.get(k) in (None, "") else float(t[k])
        t.update(value=None, alarm="", hist=[])
        self.tags.append(t)
        self.save()
        return ""

    def import_sim(self):
        st = json.load(urllib.request.urlopen(self.sim_url, timeout=3))
        n = 0
        for p in st["plcs"]:
            host = p["bind"] if p["bind"] != "0.0.0.0" else "127.0.0.1"
            if self.add_device({"name": p["name"], "vendor": p["vendor"], "host": host, "port": p["port"]}, save=False):
                continue
            n += 1
            for nm, addr, wr in (("D0", 0, False), ("D1", 1, False), ("SP", 10, True)):
                self.add_tag({"name": "%s.%s" % (p["name"], nm), "device": p["name"], "addr": addr, "writable": wr})
        self.save()
        return n

    # ---------- polling ----------
    def chunks(self, dev):
        addrs = sorted({t["addr"] for t in self.tags if t["device"] == dev.name})
        out = []
        for a in addrs:
            if out and a - (out[-1][0] + out[-1][1]) <= 8 and a - out[-1][0] < 100:
                out[-1][1] = a - out[-1][0] + 1
            else:
                out.append([a, 1])
        return out

    def alarm(self, src, kind, value=None):
        self.aid += 1
        self.alarms.append({"id": self.aid, "t": time.strftime("%H:%M:%S"), "src": src, "kind": kind,
                            "value": value, "ack": False})
        self.ev("ALARM %s %s %s" % (src, kind, "" if value is None else round(value, 2)))

    async def poll(self, dev):
        while True:
            try:
                async with dev.lock:
                    if not dev.w:
                        await dev.open()
                    vals = {}
                    for a, n in self.chunks(dev):
                        for i, w in enumerate(await dev.read_words(a, n)):
                            vals[a + i] = w
                    mode = await dev.read_mode()
                if mode != dev.mode:
                    self.ev("%s mode %s -> %s" % (dev.name, dev.mode, mode))
                dev.mode = mode
                if not dev.online:
                    self.ev("%s online" % dev.name)
                dev.online, dev.err = True, ""
                self.apply(dev, vals)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                if dev.online or not dev.err:
                    self.alarm(dev.name, "COMM LOSS")
                dev.online, dev.err = False, (str(e) or type(e).__name__)[:80]
                dev.mode = "?"
                await dev.close()
                for t in self.tags:
                    if t["device"] == dev.name:
                        t["value"] = None
            await asyncio.sleep(self.interval)

    def apply(self, dev, vals):
        for t in self.tags:
            if t["device"] != dev.name or t["addr"] not in vals:
                continue
            raw = vals[t["addr"]]
            if t.get("signed") and raw > 32767:
                raw -= 65536
            v = raw * t.get("scale", 1) + t.get("offset", 0)
            t["value"] = v
            t["hist"] = (t.get("hist") or [])[-89:] + [round(v, 3)]
            state = "HI" if t.get("hi") is not None and v > t["hi"] else ("LO" if t.get("lo") is not None and v < t["lo"] else "")
            if state and state != t.get("alarm"):
                self.alarm(t["name"], state, v)
            t["alarm"] = state

    # ---------- operator actions ----------
    async def write_tag(self, name, value):
        t = next((x for x in self.tags if x["name"] == name), None)
        dev = t and next((d for d in self.devs if d.name == t["device"]), None)
        if not t or not dev:
            return "no such tag"
        if not t.get("writable"):
            return "tag is not writable"
        raw = int(round((float(value) - t.get("offset", 0)) / (t.get("scale", 1) or 1)))
        try:
            async with dev.lock:
                if not dev.w:
                    await dev.open()
                await dev.write_word(t["addr"], raw)
        except Exception as e:
            await dev.close()
            return str(e) or type(e).__name__
        self.ev("write %s = %s" % (name, value))
        return ""

    async def command(self, name, cmd):
        dev = next((d for d in self.devs if d.name == name), None)
        if not dev or cmd not in ("start", "stop", "download"):
            return "bad request"
        try:
            async with dev.lock:
                if not dev.w:
                    await dev.open()
                await dev.command(cmd)
        except Exception as e:
            await dev.close()
            return str(e) or type(e).__name__
        self.ev("command %s -> %s" % (cmd.upper(), name))
        return ""

    async def set_node(self, cfg):
        self.node.set(cfg)
        try:
            await self.node.apply()
        except Exception as e:
            return str(e)
        for d in self.devs:
            async with d.lock:
                await d.close()
        self.ev("node network set: %s" % (self.node.ip or "host network"))
        self.save()
        return ""

    def state(self):
        return dict(
            node=dict(ip=self.node.ip, mac=self.node.mac if self.node.ip else "", prefix=self.node.prefix,
                      gateway=self.node.gateway, parent=self.node.parent, netmode=self.node.netmode),
            nics=P.list_nics(), vendors=list(DEFPORT),
            devices=[dict(name=d.name, vendor=d.vendor, host=d.host, port=d.port, online=d.online, mode=d.mode, err=d.err)
                     for d in self.devs],
            tags=[{k: t.get(k) for k in ("name", "device", "addr", "value", "alarm", "writable", "scale", "hist", "hi", "lo", "unit")}
                  for t in self.tags],
            alarms=list(self.alarms)[-30:][::-1], events=list(self.events)[-20:])


PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>SCADA</title>
<style>body{font:14px system-ui;margin:16px;background:#0b1220;color:#e5e7eb}table{border-collapse:collapse;width:100%}
td,th{padding:5px 8px;border-bottom:1px solid #243049;text-align:left}button,select,input{margin:2px;padding:5px 8px;background:#1b2740;color:#e5e7eb;border:1px solid #3b4d73;border-radius:4px}
input{width:105px}.on{color:#4ade80}.off{color:#f87171}.HI,.LO,.COMM{color:#fb923c;font-weight:bold}h4{margin:18px 0 4px}
pre{background:#000;padding:8px;font-size:12px;max-height:180px;overflow:auto}.sm{color:#94a3b8;font-size:12px}</style>
<h2>SCADA <small class=sm id=node></small></h2>
<h4>Devices</h4><div style="overflow-x:auto"><table id=dv></table></div>
<h4>Tags</h4><div style="overflow-x:auto"><table id=tg></table></div>
<h4>Alarms</h4><div style="overflow-x:auto"><table id=al></table></div>
<h4>Add device</h4><input id=dn placeholder=name><select id=dvd></select><input id=dh placeholder="host / IP"><input id=dp placeholder="port (default)" style=width:90px><button onclick=addd()>Add</button>
<button onclick="api('/api/import')">Import all simulated PLCs</button>
<h4>Add tag</h4><input id=tn placeholder="tag name"><select id=td></select><input id=ta placeholder="address (word)" style=width:100px><input id=ts placeholder=scale style=width:60px><input id=tu placeholder=unit style=width:60px>
<input id=th placeholder=hi style=width:55px><input id=tl placeholder=lo style=width:55px><label><input type=checkbox id=tw style=width:auto>writable</label><button onclick=addt()>Add</button>
<h4>SCADA network identity (own IP + MAC on the OT network)</h4><input id=ni placeholder="IP or dhcp"><input id=np value=24 style=width:45px><input id=ng placeholder=gateway><select id=nn></select>
<select id=nm><option value=vepa>macvlan vepa<option value=bridge>macvlan bridge<option value=dedicated>dedicated adapter</select><button onclick=setn()>Apply</button>
<h4>Events</h4><pre id=ev></pre>
<script>
let S={};const E=x=>x==null?'':x;
async function api(u,b){const r=await fetch(u,{method:'POST',body:JSON.stringify(b||{})});const j=await r.json().catch(()=>({}));if(j.error)alert(j.error);load()}
const addd=()=>api('/api/device',{name:dn.value,vendor:dvd.value,host:dh.value,port:dp.value||null});
const addt=()=>api('/api/tag',{name:tn.value,device:td.value,addr:ta.value||0,scale:ts.value||1,unit:tu.value,hi:th.value,lo:tl.value,writable:tw.checked});
const setn=()=>api('/api/node',{ip:ni.value,prefix:+np.value||24,gateway:ng.value,parent:nn.value,netmode:nm.value});
const cmd=(d,c)=>api('/api/cmd',{device:d,cmd:c});
function wr(n){const v=prompt('New value for '+n);if(v!==null)api('/api/write',{tag:n,value:v})}
function sp(h){h=h||[];if(h.length<2)return '';const mn=Math.min(...h),mx=Math.max(...h),r=(mx-mn)||1;return `<svg width=90 height=22><polyline fill=none stroke=#38bdf8 points="${h.map((v,i)=>(i*90/(h.length-1)).toFixed(1)+','+(20-(v-mn)/r*18).toFixed(1)).join(' ')}"/></svg>`}
async function load(){S=await (await fetch('/api/state')).json();
node.textContent=S.node.ip?`${S.node.ip}/${S.node.prefix}  MAC ${S.node.mac}`:'(no own IP set - using host network)';
if(!dvd.options.length){dvd.innerHTML=S.vendors.map(x=>`<option>${x}`).join('')}
if(document.activeElement.tagName!='SELECT'){td.innerHTML=S.devices.map(d=>`<option>${d.name}`).join('');nn.innerHTML=S.nics.map(x=>`<option ${x==S.node.parent?'selected':''}>${x}`).join('')}
dv.innerHTML='<tr><th>Device<th>Vendor<th>Address<th>Status<th>CPU mode<th>Control</tr>'+S.devices.map(d=>`<tr><td>${d.name}<td>${d.vendor}<td>${d.host}:${d.port}<td class=${d.online?'on':'off'}>${d.online?'&#9679; online':'&#9679; '+d.err}<td>${d.mode}
<td><button onclick="cmd('${d.name}','start')">Start</button><button onclick="cmd('${d.name}','stop')">Stop</button>${d.vendor=='siemens'?`<button onclick="cmd('${d.name}','download')">Download</button>`:''}<button onclick="if(confirm('Remove?'))api('/api/device/delete',{name:'${d.name}'})">&#10005;</button></tr>`).join('');
tg.innerHTML='<tr><th>Tag<th>Device<th>Addr<th>Value<th>Trend<th>Alarm<th></tr>'+S.tags.map(t=>`<tr><td>${t.name}<td>${t.device}<td>D${t.addr}<td><b>${t.value==null?'--':(+t.value).toFixed(2)}</b> ${E(t.unit)}<td>${sp(t.hist)}<td class=${t.alarm}>${t.alarm}
<td>${t.writable?`<button onclick="wr('${t.name}')">Write</button>`:''}<button onclick="api('/api/tag/delete',{name:'${t.name}'})">&#10005;</button></tr>`).join('');
al.innerHTML='<tr><th>Time<th>Source<th>Alarm<th>Value<th></tr>'+S.alarms.map(a=>`<tr><td>${a.t}<td>${a.src}<td class=COMM>${a.kind}<td>${a.value==null?'':(+a.value).toFixed(2)}<td>${a.ack?'ack':`<button onclick="api('/api/ack',{id:${a.id}})">Ack</button>`}</tr>`).join('');
ev.textContent=S.events.join('\\n')}
load();setInterval(load,1500)
</script>"""


def make_http(sc, bind, port):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, ct="application/json"):
            b = body.encode() if isinstance(body, str) else body
            self.send_response(code)
            self.send_header("Content-Type", ct)
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def _run(self, f, *a):
            async def w():
                r = f(*a)
                return await r if asyncio.iscoroutine(r) else r
            return asyncio.run_coroutine_threadsafe(w(), sc.loop).result(30)

        def _done(self, err):
            self._send(400 if err else 200, json.dumps({"error": err} if err else {"ok": True}))

        def do_GET(self):
            if self.path == "/api/state":
                self._send(200, json.dumps(sc.state()))
            else:
                self._send(200, PAGE, "text/html")

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            try:
                b = json.loads(self.rfile.read(n) or b"{}")
                p = self.path
                if p == "/api/device":
                    return self._done(self._run(sc.add_device, b))
                if p == "/api/device/delete":
                    return self._done(self._run(sc.del_device, b.get("name")))
                if p == "/api/tag":
                    return self._done(self._run(sc.add_tag, b))
                if p == "/api/tag/delete":
                    def rm():
                        sc.tags = [t for t in sc.tags if t["name"] != b.get("name")]
                        sc.save()
                        return ""
                    return self._done(self._run(rm))
                if p == "/api/write":
                    return self._done(self._run(sc.write_tag, b.get("tag"), b.get("value")))
                if p == "/api/cmd":
                    return self._done(self._run(sc.command, b.get("device"), b.get("cmd")))
                if p == "/api/import":
                    k = self._run(sc.import_sim)
                    return self._done("" if k else "no new PLCs found (is the simulator panel on 127.0.0.1:8080?)")
                if p == "/api/node":
                    return self._done(self._run(sc.set_node, b))
                if p == "/api/ack":
                    for a in sc.alarms:
                        if a["id"] == b.get("id"):
                            a["ack"] = True
                    return self._done("")
                self._done("bad request")
            except Exception as e:
                self._done(str(e) or type(e).__name__)

    srv = ThreadingHTTPServer((bind, port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print("SCADA HMI: http://%s:%d" % (bind, port), flush=True)
