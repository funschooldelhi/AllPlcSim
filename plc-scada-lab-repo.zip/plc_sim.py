#!/usr/bin/env python3
"""
plc_sim.py - multi-vendor PLC simulator for LAB / security-tool testing.
Pure Python 3.8+, no pip packages.

Emulates (enough for discovery, fingerprinting, mode read, start/stop, program download):
  Siemens     S7comm            TCP 102    (COTP, setup comm, SZL 0x0011/0x001C/0x0424, PLC stop/start, download 1A/1B/1C)
  Rockwell    EtherNet/IP + CIP TCP+UDP 44818 (ListIdentity, ListServices, Identity object, CIP Start/Stop/Reset)
  Schneider   Modbus TCP + UMAS TCP 502    (FC 1-6,15,16, FC43/14 device ID, UMAS 0x5A init/info/start/stop)
  Mitsubishi  MELSEC MC 3E binary TCP 5007 + UDP 5006 (cpu model 0101, remote RUN/STOP/PAUSE/RESET, D-register read/write)

Control panel: http://127.0.0.1:8080  (change mode RUN/STOP/PROGRAM/FAULT, simulate download, pick simulation type)

Ports 102 and 502 are privileged: run as Administrator / root (sudo python3 plc_sim.py).

Usage:
  python3 plc_sim.py                      # one PLC of each vendor on all interfaces
  python3 plc_sim.py --sample-config      # writes plcs.json (several PLCs on separate IPs)
  python3 plc_sim.py --config plcs.json
"""
import argparse, asyncio, contextlib, ctypes, ipaddress, json, math, os, random, re, shutil, signal, socket, struct, subprocess, sys, threading, time, zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MODES = ["RUN", "STOP", "PROGRAM", "FAULT", "PAUSE"]
SIMS = ["counter", "tank", "sine", "motor", "conveyor", "idle"]

VENDORS = {
    "siemens": dict(port=102, models={
        "default": dict(name="CPU 315-2 PN/DP", order="6ES7 315-2EH14-0AB0", ver=(3, 2, 8), code=0),
        "s7-1200": dict(name="CPU 1214C DC/DC/DC", order="6ES7 214-1AG40-0XB0", ver=(4, 2, 3), code=0),
        "s7-1500": dict(name="CPU 1511-1 PN", order="6ES7 511-1AK02-0AB0", ver=(2, 9, 2), code=0)}),
    "rockwell": dict(port=44818, models={
        "default": dict(name="1756-L83E/B", order="", ver=(33, 11, 0), code=166),
        "micro850": dict(name="2080-LC50-48QWB", order="", ver=(12, 0, 0), code=129),
        "compactlogix": dict(name="1769-L33ER/A LOGIX5333ER", order="", ver=(32, 11, 0), code=191)}),
    "schneider": dict(port=502, models={
        "default": dict(name="TM251MESE", order="", ver=(5, 0, 4), code=0x0A01),
        "m340": dict(name="BMX P34 2020", order="", ver=(3, 20, 0), code=0x0B01),
        "m580": dict(name="BMEP584040", order="", ver=(3, 10, 0), code=0x0C01)}),
    "mitsubishi": dict(port=5007, models={
        "default": dict(name="Q03UDECPU", order="", ver=(1, 0, 0), code=0x0268),
        "iq-r": dict(name="R04CPU", order="", ver=(1, 0, 0), code=0x4801),
        "fx5u": dict(name="FX5U-32MT/ES", order="", ver=(1, 0, 0), code=0x4A91)}),
}


def local_ip_for(peer):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((peer, 9))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


class PLC:
    def __init__(self, cfg):
        self.name = cfg["name"]
        self.vendor = cfg["vendor"].lower()
        v = VENDORS[self.vendor]
        self.cfg = dict(cfg)
        self.dhcp = str(cfg.get("ip") or "").lower() == "dhcp" or bool(cfg.get("dhcp"))
        self.ip = None if self.dhcp else (cfg.get("ip") or None)
        self.iface, self.dhcp_task = "eth0", None
        self.bind = self.ip or cfg.get("bind", "0.0.0.0")
        self.port = int(cfg.get("port") or v["port"])
        self.prefix = int(cfg.get("prefix") or 24)
        self.gateway = cfg.get("gateway") or None
        self.vlan = int(cfg["vlan"]) if cfg.get("vlan") else None
        self.parent = cfg.get("parent")
        self.netmode = "vepa" if cfg.get("netmode") in (None, "", "dedicated") else cfg["netmode"]
        self.dedicated = cfg.get("netmode") == "dedicated"
        self.mac = cfg.get("mac") or make_mac(self.vendor, self.name)
        self.ns, self.handles, self.seen = None, [], {}
        m = v["models"].get(str(cfg.get("model", "default")).lower(), v["models"]["default"])
        self.model, self.order, self.ver, self.code = m["name"], m["order"], m["ver"], m["code"]
        self.serial = zlib.crc32(self.name.encode()) & 0xFFFFFFFF
        self.mode = cfg.get("mode", "RUN").upper()
        self.sim = cfg.get("sim", "counter")
        self.program, self.version, self.downloads = "MAIN_PROG", 1, 0
        self.regs = [0] * 2000
        self.coils = [0] * 2000
        self.log = []
        self.t0 = time.time()
        self._dir = 1
        self.coils[0] = 1 if self.mode == "RUN" else 0

    # ---- state ----
    def note(self, msg):
        line = "%s [%s] %s" % (time.strftime("%H:%M:%S"), self.name, msg)
        self.log.append(line)
        del self.log[:-100]
        print(line, flush=True)

    def conn(self, proto, w):
        ip_ = (w.get_extra_info("peername") or ("?",))[0]
        now = time.time()
        if now - self.seen.get((proto, ip_), 0) > 60:
            self.note("%s connection from %s" % (proto, ip_))
        self.seen[(proto, ip_)] = now

    def set_mode(self, mode, src="panel"):
        mode = mode.upper()
        if mode not in MODES:
            return False
        if mode != self.mode:
            self.note("mode %s -> %s (via %s)" % (self.mode, mode, src))
        self.mode = mode
        self.coils[0] = 1 if mode == "RUN" else 0
        return True

    def begin_download(self, src):
        self.note("program download started (via %s)" % src)
        self.set_mode("PROGRAM", src)

    def end_download(self, src):
        self.version += 1
        self.downloads += 1
        self.note("program download finished -> %s v%d (via %s)" % (self.program, self.version, src))
        self.set_mode("STOP", src)

    def quick_download(self, src="panel"):
        self.begin_download(src)
        threading.Timer(2.0, self.end_download, args=(src,)).start()

    def tick(self):
        if self.mode != "RUN":
            return
        t, r, c = time.time() - self.t0, self.regs, self.coils
        if self.sim == "counter":
            r[0] = (r[0] + 1) & 0xFFFF
            r[1] = r[0] % 100
            c[1] = r[0] & 1
        elif self.sim == "tank":
            if r[0] >= 900:
                self._dir = -1
            elif r[0] <= 100:
                self._dir = 1
            r[0] = max(0, r[0] + self._dir * random.randint(5, 20))
            r[1] = 40 if self._dir > 0 else 0
            c[1] = 1 if self._dir > 0 else 0
        elif self.sim == "sine":
            r[0] = int(500 + 400 * math.sin(t / 5))
            r[1] = int(500 + 400 * math.cos(t / 5))
        elif self.sim == "motor":
            r[0] = int(r[0] + (1500 - r[0]) * 0.1 + random.randint(-5, 5))
            r[1] = int(40 + r[0] / 50)
            c[2] = 1
        elif self.sim == "conveyor":
            r[0] = (r[0] + random.choice([0, 0, 1])) & 0xFFFF
            c[3] = 1 if int(t) % 4 < 2 else 0

    def info(self):
        return dict(name=self.name, vendor=self.vendor, mac=self.mac if (self.ip or self.dhcp) else "", dhcp=self.dhcp, bind=self.bind, port=self.port, model=self.model,
                    mode=self.mode, program=self.program, version=self.version, downloads=self.downloads,
                    sim=self.sim, regs=self.regs[:4], log=self.log[-6:])


# =====================================================================
# Modbus TCP + Schneider UMAS
# =====================================================================
def modbus_pdu(plc, pdu):
    fc = pdu[0]

    def exc(code):
        return bytes([fc | 0x80, code])
    try:
        if fc in (1, 2):
            a, q = struct.unpack(">HH", pdu[1:5])
            if q < 1 or q > 2000 or a + q > len(plc.coils):
                return exc(2)
            bits = plc.coils[a:a + q]
            out = bytearray((q + 7) // 8)
            for i, b in enumerate(bits):
                if b:
                    out[i // 8] |= 1 << (i % 8)
            return bytes([fc, len(out)]) + bytes(out)
        if fc in (3, 4):
            a, q = struct.unpack(">HH", pdu[1:5])
            if q < 1 or q > 125 or a + q > len(plc.regs):
                return exc(2)
            return bytes([fc, q * 2]) + b"".join(struct.pack(">H", v & 0xFFFF) for v in plc.regs[a:a + q])
        if fc == 5:
            a, v = struct.unpack(">HH", pdu[1:5])
            if a >= len(plc.coils):
                return exc(2)
            plc.coils[a] = 1 if v == 0xFF00 else 0
            return pdu[:5]
        if fc == 6:
            a, v = struct.unpack(">HH", pdu[1:5])
            if a >= len(plc.regs):
                return exc(2)
            plc.regs[a] = v
            return pdu[:5]
        if fc == 15:
            a, q, n = struct.unpack(">HHB", pdu[1:6])
            if q < 1 or a + q > len(plc.coils):
                return exc(2)
            for i in range(q):
                plc.coils[a + i] = (pdu[6 + i // 8] >> (i % 8)) & 1
            return pdu[:5]
        if fc == 16:
            a, q, n = struct.unpack(">HHB", pdu[1:6])
            if q < 1 or q > 123 or a + q > len(plc.regs):
                return exc(2)
            for i in range(q):
                plc.regs[a + i] = struct.unpack(">H", pdu[6 + 2 * i:8 + 2 * i])[0]
            return pdu[:5]
        if fc == 43 and len(pdu) >= 4 and pdu[1] == 0x0E:
            code = pdu[2]
            vend = {"schneider": "Schneider Electric", "siemens": "Siemens AG",
                    "rockwell": "Rockwell Automation", "mitsubishi": "Mitsubishi Electric"}[plc.vendor]
            objs = {0: vend, 1: plc.model, 2: "V%d.%d.%d.11" % plc.ver, 3: "www.se.com", 4: plc.model, 5: plc.model,
                    6: plc.name}
            ids = [0, 1, 2] if code == 1 else ([pdu[3]] if code == 4 else list(range(0, 7)))
            body = b"".join(bytes([i, len(objs[i])]) + objs[i].encode() for i in ids if i in objs)
            return bytes([43, 0x0E, code, 0x81, 0x00, 0x00, len([i for i in ids if i in objs])]) + body
        if fc == 0x5A and len(pdu) >= 3:
            return umas(plc, pdu)
        return exc(1)
    except (struct.error, IndexError):
        return exc(3)


def umas(plc, pdu):
    sess, sub = pdu[1], pdu[2]
    ok = lambda d=b"": bytes([0x5A, sess, 0xFE]) + d
    if sub == 0x01:                       # init comm
        return ok(struct.pack("<H", 1024) + b"\x00")
    if sub in (0x02, 0x04):               # read PLC id / info
        name = plc.model.encode()
        return ok(struct.pack("<HH", plc.code, plc.version) + bytes([len(name)]) + name)
    if sub == 0x10:                       # take reservation
        return ok(b"\x01")
    if sub == 0x11 or sub == 0x12:
        return ok()
    if sub == 0x40:
        plc.set_mode("RUN", "UMAS")
        return ok()
    if sub == 0x41:
        plc.set_mode("STOP", "UMAS")
        return ok()
    if sub in (0x30, 0x31, 0x32):         # write memory / download-ish
        plc.begin_download("UMAS") if plc.mode != "PROGRAM" else None
        return ok()
    return bytes([0x5A, sess, 0xFD, sub])


async def modbus_client(plc, r, w):
    plc.conn("Modbus/UMAS", w)
    try:
        while True:
            h = await r.readexactly(7)
            tid, pid, ln, uid = struct.unpack(">HHHB", h)
            if ln < 2 or ln > 260:
                break
            pdu = await r.readexactly(ln - 1)
            resp = modbus_pdu(plc, pdu)
            w.write(struct.pack(">HHHB", tid, pid, len(resp) + 1, uid) + resp)
            await w.drain()
    except (asyncio.IncompleteReadError, ConnectionError, OSError):
        pass
    finally:
        w.close()


# =====================================================================
# Siemens S7comm
# =====================================================================
def tpkt(payload):
    return b"\x03\x00" + struct.pack(">H", len(payload) + 4) + payload


def s7_msg(rosctr, pref, param, data=b"", err=(0, 0)):
    hdr = bytes([0x32, rosctr, 0, 0]) + pref + struct.pack(">HH", len(param), len(data))
    if rosctr == 3:
        hdr += bytes(err)
    return tpkt(b"\x02\xf0\x80" + hdr + param + data)


def pad(s, n):
    return s.encode().ljust(n, b" ")[:n]


def szl_records(plc, sid, idx):
    v = plc.ver
    if sid == 0x0000:
        return 2, [struct.pack(">H", x) for x in (0x0000, 0x0011, 0x001C, 0x0424)]
    if sid == 0x0011:
        def rec(i, order, extra=b"\x00\x00\x00\x00\x00\x00"):
            return struct.pack(">H", i) + pad(order, 20) + extra
        allr = {1: rec(1, plc.order, struct.pack(">HHH", 0x0000, 0x0001, 0x0001)),
                6: rec(6, plc.order, struct.pack(">HHH", 0x0000, 0x0001, 0x0001)),
                7: rec(7, "", bytes([0x56, v[0], v[1], v[2], 0, 0]))}
        return 28, [allr[i] for i in allr if idx in (0, i)]
    if sid == 0x001C:
        items = {1: "S7-%s" % plc.name, 2: plc.model, 3: "", 4: "Original Siemens Equipment",
                 5: "S C-%08X" % plc.serial, 7: plc.model, 8: ""}
        recs = [struct.pack(">H", i) + pad(t, 32) for i, t in items.items() if idx in (0, i)]
        return 34, recs
    if sid == 0x0424:
        st = {"RUN": 0x08, "STOP": 0x04, "PROGRAM": 0x04, "PAUSE": 0x04, "FAULT": 0x04}[plc.mode]
        return 20, [bytes([0x02, 0x51, 0xFF, st]) + bytes(16)]
    return None, None


def s7_rw(plc, pref, fn, param, data):
    """S7 ReadVar/WriteVar: any area/DB is mapped onto the PLC's 16-bit register bank (big-endian words)."""
    cnt, items = param[1], []
    for k in range(cnt):
        it = param[2 + 12 * k:14 + 12 * k]
        size = {1: 1, 2: 1, 3: 1, 4: 2, 5: 2, 6: 4, 7: 4, 8: 4}.get(it[3], 1)
        items.append((struct.unpack(">H", it[4:6])[0] * size, (it[9] << 16 | it[10] << 8 | it[11]) >> 3))
    top = len(plc.regs) * 2
    if fn == 0x04:
        out = b""
        for k, (nb, off) in enumerate(items):
            if off + nb > top:
                out += bytes([0x05, 0, 0, 0])
                continue
            chunk = bytes((plc.regs[(off + j) // 2] >> (8 if (off + j) % 2 == 0 else 0)) & 0xFF for j in range(nb))
            out += bytes([0xFF, 0x04]) + struct.pack(">H", nb * 8) + chunk
            if k < len(items) - 1 and nb % 2:
                out += b"\x00"
        return s7_msg(3, pref, bytes([4, cnt]), out)
    j, res = 0, b""
    for k, (nb, off) in enumerate(items):
        n = struct.unpack(">H", data[j + 2:j + 4])[0] // 8
        payload = data[j + 4:j + 4 + n]
        j += 4 + n + (n % 2 if k < len(items) - 1 else 0)
        if off + n > top:
            res += b"\x05"
            continue
        for b_i, byte in enumerate(payload):
            pos = off + b_i
            cur = plc.regs[pos // 2]
            plc.regs[pos // 2] = ((cur & 0x00FF) | byte << 8) if pos % 2 == 0 else ((cur & 0xFF00) | byte)
        res += b"\xff"
    plc.note("S7 WriteVar %d item(s)" % cnt)
    return s7_msg(3, pref, bytes([5, cnt]), res)


def s7_request(plc, s7):
    if len(s7) < 10 or s7[0] != 0x32:
        return None
    ros, pref = s7[1], s7[4:6]
    plen, dlen = struct.unpack(">HH", s7[6:10])
    hl = 12 if ros in (2, 3) else 10
    param, data = s7[hl:hl + plen], s7[hl + plen:hl + plen + dlen]
    if ros == 1 and param:
        fn = param[0]
        if fn == 0xF0:
            return s7_msg(3, pref, bytes([0xF0, 0, 0, 1, 0, 1, 0x03, 0xC0]))
        if fn == 0x29:
            plc.set_mode("STOP", "S7 PLC-STOP")
            return s7_msg(3, pref, b"\x29\x00")
        if fn == 0x28:
            plc.set_mode("RUN", "S7 PLC-START")
            return s7_msg(3, pref, b"\x28\x00")
        if fn == 0x1A:
            plc.begin_download("S7 download")
            return s7_msg(3, pref, b"\x1a\x00")
        if fn == 0x1B:
            return s7_msg(3, pref, b"\x1b\x00")
        if fn == 0x1C:
            plc.end_download("S7 download")
            return s7_msg(3, pref, b"\x1c\x00")
        if fn in (0x04, 0x05):
            return s7_rw(plc, pref, fn, param, data)
        if fn in (0x1D, 0x1E, 0x1F):
            plc.note("S7 upload request (fn 0x%02X)" % fn)
            return s7_msg(3, pref, bytes([fn, 0]))
        return s7_msg(3, pref, b"", err=(0x81, 0x04))
    if ros == 7 and len(param) >= 8:
        grp, sub, seq = param[5] & 0x0F, param[6], param[7]
        rp = bytes([0, 1, 0x12, 8, 0x12, 0x80 | (param[5] & 0x0F), sub, seq, 0, 0, 0, 0])
        if grp == 4 and sub == 1 and len(data) >= 8:
            sid, idx = struct.unpack(">HH", data[4:8])
            rl, recs = szl_records(plc, sid, idx)
            if recs is None:
                return s7_msg(7, pref, rp[:10] + b"\xd4\x01", bytes([0x0A, 0, 0, 0]))
            body = struct.pack(">HHHH", sid, idx, rl, len(recs)) + b"".join(recs)
            return s7_msg(7, pref, rp, bytes([0xFF, 0x09]) + struct.pack(">H", len(body)) + body)
        return s7_msg(7, pref, rp[:10] + b"\x80\x04", bytes([0x0A, 0, 0, 0]))
    return s7_msg(3, pref, b"", err=(0x81, 0x04))


async def s7_client(plc, r, w):
    plc.conn("S7", w)
    try:
        while True:
            h = await r.readexactly(4)
            ln = struct.unpack(">H", h[2:4])[0]
            if h[0] != 3 or ln < 7 or ln > 4096:
                break
            body = await r.readexactly(ln - 4)
            li, kind = body[0], body[1]
            if kind == 0xE0:                      # COTP connection request
                params = body[7:1 + li]
                w.write(tpkt(bytes([li, 0xD0]) + body[4:6] + b"\x00\x01\x00" + params))
            elif kind == 0xF0:                    # COTP data
                resp = s7_request(plc, body[3:])
                if resp:
                    w.write(resp)
            await w.drain()
    except (asyncio.IncompleteReadError, ConnectionError, OSError):
        pass
    finally:
        w.close()


# =====================================================================
# Rockwell EtherNet/IP + CIP
# =====================================================================
def enip_frame(cmd, sess, ctx, data, status=0):
    return struct.pack("<HHII8sI", cmd, len(data), sess, status, ctx, 0) + data


def cip_status(plc):
    return {"RUN": (0x0030, 3), "PROGRAM": (0x0010, 4), "STOP": (0x0010, 4),
            "PAUSE": (0x0010, 4), "FAULT": (0x0001 | 0x0200, 5)}[plc.mode]


def identity_attrs(plc):
    st, _ = cip_status(plc)
    return dict(
        a1=struct.pack("<H", 1), a2=struct.pack("<H", 0x0E), a3=struct.pack("<H", plc.code),
        a4=bytes([plc.ver[0], plc.ver[1]]), a5=struct.pack("<H", st), a6=struct.pack("<I", plc.serial),
        a7=bytes([len(plc.model)]) + plc.model.encode(), a8=bytes([cip_status(plc)[1]]))


def identity_item(plc, ip):
    a = identity_attrs(plc)
    body = (struct.pack("<H", 1) + struct.pack(">HH4s8s", 2, plc.port, socket.inet_aton(ip), bytes(8)) +
            a["a1"] + a["a2"] + a["a3"] + a["a4"] + a["a5"] + a["a6"] + a["a7"] + a["a8"])
    return struct.pack("<HH", 0x0C, len(body)) + body


def cip_tag(plc, svc, path, body):
    """Logix-style Read/Write Tag. Tag 'D' with an element segment (or 'D<n>') maps to 16-bit registers."""
    n = path[1]
    name = path[2:2 + n].decode(errors="ignore")
    i, idx = 2 + n + (n & 1), 0
    if i < len(path):
        if path[i] == 0x28:
            idx = path[i + 1]
        elif path[i] == 0x29:
            idx = struct.unpack("<H", path[i + 2:i + 4])[0]
        elif path[i] == 0x2A:
            idx = struct.unpack("<I", path[i + 2:i + 6])[0]
    m = re.fullmatch(r"D(\d*)", name)
    if not m:
        return bytes([svc | 0x80, 0, 0x04, 0])           # path segment error: unknown tag
    idx += int(m.group(1) or 0)
    try:
        if svc == 0x4C:
            cnt = struct.unpack("<H", body[:2])[0]
            if cnt < 1 or idx + cnt > len(plc.regs):
                return bytes([svc | 0x80, 0, 0x05, 0])
            return bytes([svc | 0x80, 0, 0, 0]) + struct.pack("<H", 0xC3) + \
                b"".join(struct.pack("<H", v & 0xFFFF) for v in plc.regs[idx:idx + cnt])
        typ, cnt = struct.unpack("<HH", body[:4])
        if cnt < 1 or idx + cnt > len(plc.regs):
            return bytes([svc | 0x80, 0, 0x05, 0])
        for k in range(cnt):
            plc.regs[idx + k] = struct.unpack("<H", body[4 + 2 * k:6 + 2 * k])[0]
        plc.note("CIP WriteTag D[%d] x%d" % (idx, cnt))
        return bytes([svc | 0x80, 0, 0, 0])
    except struct.error:
        return bytes([svc | 0x80, 0, 0x13, 0])


def cip_request(plc, cip):
    if len(cip) < 2:
        return b"\x00\x00\x05\x00"
    svc, psz = cip[0], cip[1]
    path = cip[2:2 + psz * 2]
    if path[:1] == b"\x91" and svc in (0x4C, 0x4D):
        return cip_tag(plc, svc, path, cip[2 + psz * 2:])
    cls = inst = attr = None
    i = 0
    while i < len(path):
        s = path[i]
        if s == 0x20:
            cls = path[i + 1]; i += 2
        elif s == 0x21:
            cls = struct.unpack("<H", path[i + 2:i + 4])[0]; i += 4
        elif s == 0x24:
            inst = path[i + 1]; i += 2
        elif s == 0x25:
            inst = struct.unpack("<H", path[i + 2:i + 4])[0]; i += 4
        elif s == 0x30:
            attr = path[i + 1]; i += 2
        else:
            break
    ok = lambda d=b"": bytes([svc | 0x80, 0, 0, 0]) + d
    err = lambda c: bytes([svc | 0x80, 0, c, 0])
    if cls == 1 and inst in (1, 0):
        a = identity_attrs(plc)
        if svc == 0x01:
            return ok(b"".join(a["a%d" % i] for i in range(1, 9)))
        if svc == 0x0E:
            return ok(a["a%d" % attr]) if attr and "a%d" % attr in a else err(0x14)
        if svc == 0x06:
            plc.set_mode("RUN", "CIP Start"); return ok()
        if svc == 0x07:
            plc.set_mode("STOP", "CIP Stop"); return ok()
        if svc == 0x05:
            plc.set_mode("STOP", "CIP Reset"); threading.Timer(2, plc.set_mode, args=("RUN", "CIP Reset")).start(); return ok()
        return err(0x08)
    return err(0x05)


def enip_handle(plc, data, sessions, ip, udp=False):
    cmd, ln, sess, st, ctx, opt = struct.unpack("<HHII8sI", data[:24])
    pl = data[24:24 + ln]
    if cmd == 0x63:
        return enip_frame(0x63, sess, ctx, struct.pack("<H", 1) + identity_item(plc, ip))
    if udp:
        return None
    if cmd == 0x04:
        name = b"Communications".ljust(16, b"\0")
        item = struct.pack("<HHHH", 0x100, 20, 1, 0x0120) + name
        return enip_frame(0x04, sess, ctx, struct.pack("<H", 1) + item)
    if cmd == 0x65:
        sid = random.randint(1, 0xFFFFFFF)
        sessions.add(sid)
        return enip_frame(0x65, sid, ctx, struct.pack("<HH", 1, 0))
    if cmd == 0x66:
        return None
    if cmd == 0x6F:
        if sess not in sessions:
            return enip_frame(0x6F, sess, ctx, b"", status=0x64)
        n = struct.unpack("<H", pl[6:8])[0]
        i, cip = 8, b""
        for _ in range(n):
            t, l = struct.unpack("<HH", pl[i:i + 4])
            if t == 0xB2:
                cip = pl[i + 4:i + 4 + l]
            i += 4 + l
        rep = cip_request(plc, cip)
        out = struct.pack("<IHH", 0, 0, 2) + bytes(4) + struct.pack("<HH", 0xB2, len(rep)) + rep
        return enip_frame(0x6F, sess, ctx, out)
    return enip_frame(cmd, sess, ctx, b"", status=1)


async def enip_client(plc, r, w):
    sessions = set()
    ip = (w.get_extra_info("sockname") or ("127.0.0.1",))[0]
    plc.conn("EtherNet/IP", w)
    try:
        while True:
            h = await r.readexactly(24)
            ln = struct.unpack("<H", h[2:4])[0]
            data = h + (await r.readexactly(ln) if ln else b"")
            resp = enip_handle(plc, data, sessions, ip)
            if resp:
                w.write(resp)
                await w.drain()
    except (asyncio.IncompleteReadError, ConnectionError, OSError, struct.error):
        pass
    finally:
        w.close()


class UdpProto(asyncio.DatagramProtocol):
    def __init__(self, handler):
        self.handler = handler

    def connection_made(self, t):
        self.t = t

    def datagram_received(self, data, addr):
        try:
            resp = self.handler(data, addr)
            if resp:
                self.t.sendto(resp, addr)
        except Exception:
            pass


# =====================================================================
# Mitsubishi MELSEC MC protocol 3E (binary)
# =====================================================================
def mc_frame(plc, data):
    """data = full 3E request frame (>= 11 bytes). Returns response or None."""
    if len(data) < 15 or data[0:2] != b"\x50\x00":
        return None
    hdr = data[2:7]
    cmd, sub = struct.unpack("<HH", data[11:15])
    d = data[15:]
    end, payload = 0, b""

    def resp():
        return b"\xd0\x00" + hdr + struct.pack("<H", 2 + len(payload)) + struct.pack("<H", end) + payload
    try:
        if cmd == 0x0101:
            payload = plc.model.encode().ljust(16, b" ") + struct.pack("<H", plc.code)
        elif cmd == 0x1001:
            plc.set_mode("RUN", "MC remote RUN")
        elif cmd == 0x1002:
            plc.set_mode("STOP", "MC remote STOP")
        elif cmd == 0x1003:
            plc.set_mode("PAUSE", "MC remote PAUSE")
        elif cmd in (0x1005, 0x1006):
            plc.set_mode("STOP", "MC remote RESET/latch-clear")
        elif cmd == 0x0401:
            head = d[0] | d[1] << 8 | d[2] << 16
            pts = struct.unpack("<H", d[4:6])[0]
            if d[3] == 0xA9:                      # special registers: SD203 = CPU operating status
                cs = {"RUN": 0, "PAUSE": 3}.get(plc.mode, 2)
                payload = b"".join(struct.pack("<H", cs if head + i == 203 else 0) for i in range(pts))
            elif sub & 1:
                bits = plc.coils[head:head + pts] + [0]
                payload = bytes((bits[i] << 4) | bits[i + 1] for i in range(0, pts, 2))
            else:
                payload = b"".join(struct.pack("<H", v & 0xFFFF) for v in plc.regs[head:head + pts])
        elif cmd == 0x1401:
            head = d[0] | d[1] << 8 | d[2] << 16
            pts = struct.unpack("<H", d[4:6])[0]
            if not sub & 1:
                for i in range(pts):
                    plc.regs[head + i] = struct.unpack("<H", d[6 + 2 * i:8 + 2 * i])[0]
        elif cmd == 0x0619:
            n = struct.unpack("<H", d[:2])[0]
            payload = struct.pack("<H", n) + d[2:2 + n]
        else:
            end = 0xC059
    except (IndexError, struct.error):
        end, payload = 0xC050, b""
    return resp()


async def mc_client(plc, r, w):
    plc.conn("MELSEC MC", w)
    try:
        while True:
            h = await r.readexactly(9)
            ln = struct.unpack("<H", h[7:9])[0]
            if h[0:2] != b"\x50\x00" or ln > 4096:
                break
            body = await r.readexactly(ln)
            resp = mc_frame(plc, h + body)
            if resp:
                w.write(resp)
                await w.drain()
    except (asyncio.IncompleteReadError, ConnectionError, OSError):
        pass
    finally:
        w.close()


DEFAULT_CFG = [
    {"name": "SIEMENS-S7-300", "vendor": "siemens", "model": "default", "sim": "tank"},
    {"name": "ROCKWELL-CLX", "vendor": "rockwell", "model": "default", "sim": "motor"},
    {"name": "SCHNEIDER-M251", "vendor": "schneider", "model": "default", "sim": "sine"},
    {"name": "MITSUBISHI-Q03UDE", "vendor": "mitsubishi", "model": "default", "sim": "conveyor"},
]


# =====================================================================
# Linux network namespaces: every PLC gets its own namespace, MAC and IP
# =====================================================================
NETNS_OK = sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0 and bool(shutil.which("ip"))
OUI = {"siemens": "00:0e:8c", "rockwell": "00:1d:9c", "schneider": "00:80:f4", "mitsubishi": None}
CLONE_NEWNET = 0x40000000
_libc = None


def _setns(fd):
    global _libc
    if _libc is None:
        _libc = ctypes.CDLL("libc.so.6", use_errno=True)
    if _libc.setns(fd, CLONE_NEWNET) != 0:
        raise OSError(ctypes.get_errno(), "setns failed")


@contextlib.contextmanager
def in_ns(name):
    """Run a block with the *calling thread* inside network namespace `name` (no-op if falsy)."""
    if not name:
        yield
        return
    orig = os.open("/proc/thread-self/ns/net", os.O_RDONLY)
    tgt = os.open("/var/run/netns/" + name, os.O_RDONLY)
    try:
        _setns(tgt)
        try:
            yield
        finally:
            _setns(orig)
    finally:
        os.close(tgt)
        os.close(orig)


def ipcmd(*a):
    r = subprocess.run(["ip"] + list(a), capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError("ip %s: %s" % (" ".join(a), r.stderr.strip()))
    return r.stdout


def list_nics():
    try:
        return sorted(n for n in os.listdir("/sys/class/net") if n != "lo")
    except OSError:
        return []


def make_mac(vendor, name):
    h = zlib.crc32(name.encode()) & 0xFFFFFF
    oui = OUI.get(vendor) or "02:00:00"      # locally-administered fallback; set "mac" yourself for a real OUI
    return "%s:%02x:%02x:%02x" % (oui, h >> 16 & 255, h >> 8 & 255, h & 255)


def setup_ns(p):
    p.ns = "plc_%s_%04x" % (re.sub(r"[^A-Za-z0-9]", "", p.name)[:16], zlib.crc32(p.name.encode()) & 0xFFFF)
    subprocess.run(["ip", "netns", "del", p.ns], capture_output=True)
    ipcmd("netns", "add", p.ns)
    try:
        ipcmd("-n", p.ns, "link", "set", "lo", "up")
        if p.dedicated:                                  # move a whole VM adapter into the PLC's namespace
            iface = p.parent
            ipcmd("link", "set", p.parent, "down")
            ipcmd("link", "set", p.parent, "netns", p.ns)
            if p.cfg.get("mac"):
                ipcmd("-n", p.ns, "link", "set", iface, "address", p.cfg["mac"])
            else:
                m = re.search(r"link/ether ([0-9a-f:]{17})", ipcmd("-n", p.ns, "-o", "link", "show", iface))
                if m:
                    p.mac = m.group(1)
        else:                                            # macvlan = own MAC on a shared adapter
            iface, parent = "eth0", p.parent
            ipcmd("link", "set", p.parent, "up")
            if p.vlan:
                parent = "%s.%d" % (p.parent, p.vlan)
                if not os.path.exists("/sys/class/net/" + parent):
                    ipcmd("link", "add", "link", p.parent, "name", parent, "type", "vlan", "id", str(p.vlan))
                ipcmd("link", "set", parent, "up")
            tmp = "pm%08x" % (zlib.crc32(p.name.encode()) & 0xFFFFFFFF)
            ipcmd("link", "add", "link", parent, "name", tmp, "address", p.mac, "type", "macvlan", "mode", p.netmode)
            ipcmd("link", "set", tmp, "netns", p.ns)
            ipcmd("-n", p.ns, "link", "set", tmp, "name", iface)
        p.iface = iface
        if getattr(p, "dhcp", False):
            ipcmd("-n", p.ns, "link", "set", iface, "up")          # address comes from DHCP (dhcp_lease)
        else:
            ipcmd("-n", p.ns, "addr", "add", "%s/%d" % (p.ip, p.prefix), "dev", iface)
            ipcmd("-n", p.ns, "link", "set", iface, "up")
            if p.gateway:
                ipcmd("-n", p.ns, "route", "add", "default", "via", p.gateway)
    except Exception:
        subprocess.run(["ip", "netns", "del", p.ns], capture_output=True)
        p.ns = None
        raise


def teardown_ns(p):
    t = getattr(p, "dhcp_task", None)
    if t:
        try:
            t.cancel()
        except Exception:
            pass
        p.dhcp_task = None
    if p.ns and NETNS_OK:
        subprocess.run(["ip", "netns", "del", p.ns], capture_output=True)
    p.ns = None


def cleanup_stale():
    if NETNS_OK:
        for n in subprocess.run(["ip", "netns", "list"], capture_output=True, text=True).stdout.split("\n"):
            n = n.split(" ")[0]
            if n.startswith("plc_"):
                subprocess.run(["ip", "netns", "del", n], capture_output=True)


# =====================================================================
# DHCP client: every PLC / SCADA identity leases its OWN address inside its namespace
# (own MAC as client id, PLC name as hostname -> shows up per device in your DHCP server)
# =====================================================================
DHCP_MIN_RENEW = 10.0


def _dhcp_build(mac, xid, mtype, name, req_ip=None, server=None):
    mb = bytes.fromhex(mac.replace(":", ""))
    pkt = struct.pack("!BBBBIHH4s4s4s4s", 1, 1, 6, 0, xid, 0, 0x8000, bytes(4), bytes(4), bytes(4), bytes(4))
    pkt += mb + bytes(10) + bytes(64) + bytes(128) + b"\x63\x82\x53\x63"
    nm = re.sub(r"[^A-Za-z0-9-]", "-", name)[:30].encode()
    o = bytes([53, 1, mtype, 61, 7, 1]) + mb + bytes([12, len(nm)]) + nm
    if req_ip:
        o += bytes([50, 4]) + socket.inet_aton(req_ip)
    if server:
        o += bytes([54, 4]) + socket.inet_aton(server)
    return pkt + o + bytes([55, 6, 1, 3, 6, 15, 51, 54, 255])


def _dhcp_parse(data, xid, mac):
    if (len(data) < 241 or data[0] != 2 or struct.unpack("!I", data[4:8])[0] != xid
            or data[28:34] != bytes.fromhex(mac.replace(":", "")) or data[236:240] != b"\x63\x82\x53\x63"):
        return None
    opts, i = {}, 240
    while i < len(data) and data[i] != 255:
        if data[i] == 0:
            i += 1
            continue
        if i + 1 >= len(data):
            break
        ln = data[i + 1]
        opts[data[i]] = data[i + 2:i + 2 + ln]
        i += 2 + ln
    return socket.inet_ntoa(data[16:20]), opts


class _Dhcp:
    def __init__(self, p, dest, cport, bind_dev):
        self.p, self.dest, self.xid = p, dest, random.getrandbits(32)
        with in_ns(p.ns):
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            if bind_dev:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BINDTODEVICE, p.iface.encode())
            s.bind(("0.0.0.0", cport))
            s.setblocking(False)
        self.s = s

    def send(self, mtype, **kw):
        self.s.sendto(_dhcp_build(self.p.mac, self.xid, mtype, self.p.name, **kw), self.dest)

    async def wait(self, types, t):
        loop = asyncio.get_running_loop()
        end = loop.time() + t
        while True:
            rem = end - loop.time()
            if rem <= 0:
                return None
            try:
                data = await asyncio.wait_for(loop.sock_recv(self.s, 1500), rem)
            except asyncio.TimeoutError:
                return None
            r = _dhcp_parse(data, self.xid, self.p.mac)
            if r and r[1].get(53, b"\0")[0] in types:
                return r

    async def acquire(self, tries, timeout):
        for _ in range(tries):
            self.xid = random.getrandbits(32)
            self.send(1)                                                    # DISCOVER
            off = await self.wait((2,), timeout)
            if not off:
                continue
            srv = off[1].get(54)
            self.send(3, req_ip=off[0], server=socket.inet_ntoa(srv) if srv else None)   # REQUEST
            ack = await self.wait((5, 6), timeout)
            if ack and ack[1][53][0] == 5:
                return ack
        return None

    async def renew(self, ip, lease):
        while True:
            await asyncio.sleep(max(DHCP_MIN_RENEW, lease / 2.0))
            self.xid = random.getrandbits(32)
            self.send(3, req_ip=ip)                                         # re-request same address
            ack = await self.wait((5, 6), 5)
            if ack and ack[1][53][0] == 5 and ack[0] == ip:
                lease = int.from_bytes(ack[1].get(51, b"\x00\x00\x0e\x10"), "big")
            else:
                self.p.note("DHCP renew failed for %s (retrying)" % ip)


async def dhcp_lease(p, dest=("255.255.255.255", 67), cport=68, bind_dev=True, timeout=4.0, tries=4):
    """Lease an address on p.iface inside p.ns, configure it, keep renewing in the background."""
    d = _Dhcp(p, dest, cport, bind_dev)
    ack = await d.acquire(tries, timeout)
    if not ack:
        d.s.close()
        raise RuntimeError("no DHCP answer on %s after %d tries (is a DHCP server reachable on that vSwitch/VLAN?)"
                           % (p.parent or p.iface, tries))
    ip, o = ack
    prefix = bin(int.from_bytes(o[1], "big")).count("1") if o.get(1) else 24
    gw = socket.inet_ntoa(o[3][:4]) if o.get(3) else None
    lease = int.from_bytes(o[51], "big") if o.get(51) else 3600
    ipcmd("-n", p.ns, "addr", "add", "%s/%d" % (ip, prefix), "dev", p.iface)
    if gw:
        ipcmd("-n", p.ns, "route", "add", "default", "via", gw)
    p.ip = p.bind = ip
    p.prefix, p.gateway, p.lease = prefix, gw, lease
    p.dhcp_task = asyncio.ensure_future(d.renew(ip, lease))
    if hasattr(p, "note"):
        p.note("DHCP lease %s/%d gw %s lease %ds" % (ip, prefix, gw, lease))
    return ip


def mk_sock(p, kind, port):
    with in_ns(p.ns):
        s = socket.socket(socket.AF_INET, kind)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((p.bind, port))
        if kind == socket.SOCK_STREAM:
            s.listen(64)
        s.setblocking(False)
    return s


# =====================================================================
# PLC -> PLC traffic (so a SPAN/TAP on the vSwitch sees real east-west flows)
# =====================================================================
async def ns_connect(src, dst_ip, port):
    with in_ns(src.ns):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setblocking(False)
        s.bind((src.bind, 0))
    await asyncio.wait_for(asyncio.get_running_loop().sock_connect(s, (dst_ip, port)), 3)
    return await asyncio.open_connection(sock=s)


async def poll_once(src, dst):
    """src PLC acts as a client of dst PLC using dst's native protocol."""
    r, w = await ns_connect(src, dst.bind if dst.bind != "0.0.0.0" else "127.0.0.1", dst.port)

    async def rd(n):
        return await asyncio.wait_for(r.readexactly(n), 3)

    async def tp():
        h = await rd(4)
        return h + await rd(struct.unpack(">H", h[2:4])[0] - 4)
    try:
        v = dst.vendor
        if v == "schneider":
            w.write(struct.pack(">HHHB", 1, 0, 6, 1) + bytes([3, 0, 0, 0, 10]))
            h = await rd(7)
            await rd(struct.unpack(">H", h[4:6])[0] - 1)
            w.write(struct.pack(">HHHB", 2, 0, 4, 1) + bytes([43, 14, 1, 0]))
            h = await rd(7)
            await rd(struct.unpack(">H", h[4:6])[0] - 1)
        elif v == "siemens":
            w.write(bytes.fromhex("0300001611e00000000100c0010ac1020100c2020102"))
            await tp()

            def s7(ros, p_, d_=b""):
                return tpkt(b"\x02\xf0\x80" + bytes([0x32, ros, 0, 0, 0, 1]) + struct.pack(">HH", len(p_), len(d_)) + p_ + d_)
            w.write(s7(1, bytes.fromhex("f0000001000103c0")))
            await tp()
            w.write(s7(7, bytes.fromhex("0001120411440100"), bytes.fromhex("ff090004") + struct.pack(">HH", 0x0424, 0)))
            await tp()
        elif v == "rockwell":
            ctx = b"pollpoll"
            w.write(enip_frame(0x65, 0, ctx, struct.pack("<HH", 1, 0)))
            h = await rd(24)
            sess = struct.unpack("<I", h[4:8])[0]
            await rd(struct.unpack("<H", h[2:4])[0])
            cip = bytes([0x01, 2, 0x20, 1, 0x24, 1])
            d = struct.pack("<IHH", 0, 0, 2) + bytes(4) + struct.pack("<HH", 0xB2, len(cip)) + cip
            w.write(enip_frame(0x6F, sess, ctx, d))
            h = await rd(24)
            await rd(struct.unpack("<H", h[2:4])[0])
        elif v == "mitsubishi":
            def mc(cmd, d_=b""):
                body = struct.pack("<HHH", 0x10, cmd, 0) + d_
                return b"\x50\x00\x00\xff\xff\x03\x00" + struct.pack("<H", len(body)) + body
            for m in (mc(0x0101), mc(0x0401, bytes([0, 0, 0, 0xA8, 10, 0]))):
                w.write(m)
                h = await rd(9)
                await rd(struct.unpack("<H", h[7:9])[0])
        await w.drain()
    finally:
        w.close()


# =====================================================================
# Manager: add / remove PLCs and traffic links at runtime
# =====================================================================
class Sim:
    def __init__(self, path):
        self.plcs, self.links, self.tasks, self.path, self.loop = [], [], {}, path, None

    def get(self, name):
        return next((p for p in self.plcs if p.name == name), None)

    def save(self):
        if not self.path:
            return
        try:
            plcs = []
            for p in self.plcs:
                c = dict(p.cfg)
                c["sim"], c["mode"] = p.sim, p.mode
                plcs.append(c)
            json.dump({"plcs": plcs, "links": [{k: l[k] for k in ("from", "to", "every")} for l in self.links]},
                      open(self.path, "w"), indent=2)
        except OSError as e:
            print("cannot save config:", e)

    def state(self):
        return dict(plcs=[p.info() for p in self.plcs], links=[dict(l) for l in self.links], nics=list_nics(),
                    models={v: list(d["models"]) for v, d in VENDORS.items()}, netns=bool(NETNS_OK))

    async def start_plc(self, p):
        loop = asyncio.get_running_loop()
        if p.ip or p.dhcp:
            if not NETNS_OK:
                raise RuntimeError("per-PLC IP/MAC needs Linux + root + iproute2 (use the VM appliance)")
            setup_ns(p)
            if p.dhcp:
                try:
                    await dhcp_lease(p)
                except Exception:
                    teardown_ns(p)
                    raise
        cb = {"siemens": s7_client, "rockwell": enip_client, "schneider": modbus_client, "mitsubishi": mc_client}[p.vendor]
        try:
            srv = await asyncio.start_server(lambda r, w: cb(p, r, w), sock=mk_sock(p, socket.SOCK_STREAM, p.port))
            p.handles.append(srv)
            if p.vendor == "rockwell":
                sess = set()
                tr, _ = await loop.create_datagram_endpoint(
                    lambda: UdpProto(lambda d, a: enip_handle(
                        p, d, sess, p.bind if p.bind != "0.0.0.0" else local_ip_for(a[0]), udp=True)),
                    sock=mk_sock(p, socket.SOCK_DGRAM, p.port))
                p.handles.append(tr)
            if p.vendor == "mitsubishi":
                tr, _ = await loop.create_datagram_endpoint(lambda: UdpProto(lambda d, a: mc_frame(p, d)),
                                                            sock=mk_sock(p, socket.SOCK_DGRAM, p.port - 1))
                p.handles.append(tr)
        except Exception:
            self.stop_plc(p)
            raise
        p.note("started %s %s at %s:%d%s" % (p.vendor, p.model, p.bind, p.port, " mac " + p.mac if p.ns else ""))

    def stop_plc(self, p):
        for h in p.handles:
            try:
                h.close()
            except Exception:
                pass
        p.handles = []
        teardown_ns(p)

    async def add(self, cfg, save=True):
        try:
            cfg = dict(cfg)
            name = str(cfg.get("name", "")).strip()
            cfg["name"] = name
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,40}", name):
                return "name: use letters, digits, - _ . (max 40)"
            if self.get(name):
                return "name already exists"
            if str(cfg.get("vendor", "")).lower() not in VENDORS:
                return "unknown vendor"
            ipv = str(cfg.get("ip") or "").strip()
            if cfg.get("dhcp"):
                ipv = "dhcp"
            if ipv:
                if ipv.lower() == "dhcp":
                    ipv = "dhcp"
                else:
                    ipaddress.IPv4Address(ipv)
                    if any(q.ip == ipv for q in self.plcs):
                        return "IP already used by another simulated PLC"
                if not cfg.get("parent"):
                    return "choose the VM adapter (NIC) to attach this PLC to"
                cfg["ip"] = ipv
            else:
                cfg.pop("ip", None)
            p = PLC(cfg)
            if not (p.ip or p.dhcp) and any(q.bind == p.bind and q.port == p.port for q in self.plcs):
                return "that address:port is already used"
            await self.start_plc(p)
        except Exception as e:
            return str(e) or type(e).__name__
        self.plcs.append(p)
        if save:
            self.save()
        return ""

    async def remove(self, name):
        p = self.get(name)
        if not p:
            return "no such PLC"
        for l in [l for l in self.links if name in (l["from"], l["to"])]:
            await self.del_link(l["from"], l["to"], save=False)
        self.stop_plc(p)
        self.plcs.remove(p)
        p.note("removed")
        self.save()
        return ""

    async def add_link(self, a, b, every=2.0, save=True):
        if a == b or not self.get(a) or not self.get(b):
            return "choose two different existing PLCs"
        if (a, b) in self.tasks:
            return "link exists"
        lk = {"from": a, "to": b, "every": max(0.2, float(every)), "ok": None, "err": ""}
        self.links.append(lk)
        self.tasks[(a, b)] = asyncio.ensure_future(self.link_loop(lk))
        if save:
            self.save()
        return ""

    async def del_link(self, a, b, save=True):
        t = self.tasks.pop((a, b), None)
        if t:
            t.cancel()
        self.links = [l for l in self.links if (l["from"], l["to"]) != (a, b)]
        if save:
            self.save()
        return ""

    async def link_loop(self, lk):
        while True:
            src, dst = self.get(lk["from"]), self.get(lk["to"])
            if not src or not dst:
                return
            try:
                await asyncio.wait_for(poll_once(src, dst), 8)
                lk["ok"], lk["err"] = True, ""
            except Exception as e:
                lk["ok"], lk["err"] = False, (str(e) or type(e).__name__)[:80]
            await asyncio.sleep(lk["every"])


# =====================================================================
# Web control panel
# =====================================================================
PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><title>PLC Simulator</title>
<style>body{font:14px system-ui;margin:16px;background:#111;color:#eee}table{border-collapse:collapse;width:100%}
td,th{padding:6px 8px;border-bottom:1px solid #333;text-align:left}button,select,input{margin:2px;padding:5px 8px;background:#222;color:#eee;border:1px solid #555;border-radius:4px}
input{width:110px}.RUN{color:#4ade80}.STOP{color:#f87171}.PROGRAM{color:#fbbf24}.FAULT{color:#f472b6}.PAUSE{color:#60a5fa}
pre{background:#000;padding:8px;font-size:12px;max-height:200px;overflow:auto}.ok{color:#4ade80}.bad{color:#f87171}</style>
<h2>PLC Simulator <small id=ns></small></h2><div style="overflow-x:auto"><table id=t></table></div>
<h4>Add PLC (own MAC + IP)</h4>
<div id=add>
<input id=n placeholder=name><select id=v onchange=fm()></select><select id=m></select>
<input id=ip placeholder="IP or dhcp"><input id=pf value=24 style=width:50px><input id=gw placeholder=gateway>
<input id=vl placeholder=VLAN style=width:60px><select id=nic></select>
<select id=nm><option value=vepa>macvlan vepa (via switch)<option value=bridge>macvlan bridge (local)<option value=dedicated>dedicated adapter</select>
<input id=mac placeholder="MAC (optional)"><button onclick=addp()>Add</button></div>
<h4>Traffic between PLCs (visible on SPAN)</h4>
<div><select id=lf></select> &rarr; <select id=lt></select> every <input id=le value=2 style=width:50px>s <button onclick=addl()>Add link</button></div>
<div id=ll></div><h4>Events</h4><pre id=l></pre>
<script>
const SIMS=%SIMS%,MODES=%MODES%;let S={};
async function api(u,b){const r=await fetch(u,{method:'POST',body:JSON.stringify(b||{})});const j=await r.json().catch(()=>({}));if(j.error)alert(j.error);load()}
const post=(n,a,b)=>api('/api/plc/'+encodeURIComponent(n)+'/'+a,b);
function fm(){m.innerHTML=(S.models[v.value]||[]).map(x=>`<option>${x}`).join('')}
function addp(){api('/api/plc',{name:n.value,vendor:v.value,model:m.value,ip:ip.value,prefix:+pf.value||24,gateway:gw.value,vlan:+vl.value||null,parent:nic.value,netmode:nm.value,mac:mac.value||null})}
function addl(){api('/api/link',{from:lf.value,to:lt.value,every:+le.value||2})}
async function load(){S=await (await fetch('/api/state')).json();ns.textContent=S.netns?'':'(per-PLC IPs unavailable: not Linux root)';
if(!v.options.length){v.innerHTML=Object.keys(S.models).map(x=>`<option>${x}`).join('');fm()}
if(!document.activeElement||document.activeElement.tagName!='SELECT'){nic.innerHTML=S.nics.map(x=>`<option>${x}`).join('');
const o=S.plcs.map(p=>`<option>${p.name}`).join('');lf.innerHTML=o;lt.innerHTML=o}
let h='<tr><th>Name<th>Vendor/Model<th>IP:port<th>MAC<th>Mode<th>Program<th>Sim<th>D0..D3<th>Control</tr>',lg=[];
for(const p of S.plcs){lg=lg.concat(p.log);h+=`<tr><td>${p.name}<td>${p.vendor} ${p.model}<td>${p.bind}:${p.port}${p.dhcp?' (DHCP)':''}<td>${p.mac||''}<td class=${p.mode}><b>${p.mode}</b>
<td>${p.program} v${p.version} (dl:${p.downloads})<td><select onchange="post('${p.name}','sim',{sim:this.value})">${SIMS.map(s=>`<option ${s==p.sim?'selected':''}>${s}`).join('')}</select>
<td>${p.regs.join(', ')}<td>${MODES.map(x=>`<button onclick="post('${p.name}','mode',{mode:'${x}'})">${x}</button>`).join('')}<button onclick="post('${p.name}','download')">Download prog</button><button onclick="if(confirm('Remove ${p.name}?'))post('${p.name}','delete')">&#10005;</button></tr>`}
t.innerHTML=h;ll.innerHTML=S.links.map(k=>`<div><span class=${k.ok?'ok':'bad'}>&#9679;</span> ${k.from} &rarr; ${k.to} every ${k.every}s ${k.err||''} <button onclick="api('/api/link/delete',{from:'${k.from}',to:'${k.to}'})">remove</button></div>`).join('');
l.textContent=lg.sort().slice(-25).join('\\n')}
load();setInterval(load,2000)
</script>"""


def make_panel(sim, bind, port):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, ct="application/json"):
            b = body.encode() if isinstance(body, str) else body
            self.send_response(code)
            self.send_header("Content-Type", ct)
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def _run(self, coro):
            return asyncio.run_coroutine_threadsafe(coro, sim.loop).result(30)

        def _done(self, err):
            self._send(400 if err else 200, json.dumps({"error": err} if err else {"ok": True}))

        def do_GET(self):
            if self.path == "/api/state":
                self._send(200, json.dumps(sim.state()))
            else:
                self._send(200, PAGE.replace("%SIMS%", json.dumps(SIMS)).replace("%MODES%", json.dumps(MODES)),
                           "text/html")

        def do_POST(self):
            from urllib.parse import unquote
            parts = [unquote(x) for x in self.path.strip("/").split("/")]
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
                if parts == ["api", "plc"]:
                    return self._done(self._run(sim.add(body)))
                if parts == ["api", "link"]:
                    return self._done(self._run(sim.add_link(body.get("from"), body.get("to"), body.get("every", 2))))
                if parts == ["api", "link", "delete"]:
                    return self._done(self._run(sim.del_link(body.get("from"), body.get("to"))))
                if len(parts) == 4 and parts[:2] == ["api", "plc"]:
                    p, act = sim.get(parts[2]), parts[3]
                    if not p:
                        return self._done("no such PLC")
                    if act == "mode":
                        ok = p.set_mode(body.get("mode", ""), "panel")
                        sim.save()
                        return self._done("" if ok else "bad mode")
                    if act == "download":
                        p.quick_download("panel")
                        return self._done("")
                    if act == "sim" and body.get("sim") in SIMS:
                        p.sim = body["sim"]
                        p.note("simulation type -> %s" % p.sim)
                        sim.save()
                        return self._done("")
                    if act == "delete":
                        return self._done(self._run(sim.remove(parts[2])))
                self._done("bad request")
            except Exception as e:
                self._done(str(e) or type(e).__name__)

    srv = ThreadingHTTPServer((bind, port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print("Control panel: http://%s:%d" % (bind, port), flush=True)


# =====================================================================
# main
# =====================================================================
SAMPLE = {
    "plcs": [
        {"name": "S7-1200-LINE1", "vendor": "siemens", "model": "s7-1200", "ip": "10.10.10.11", "prefix": 24, "gateway": "10.10.10.1", "parent": "eth1", "netmode": "vepa", "sim": "tank"},
        {"name": "CLX-PACKAGING", "vendor": "rockwell", "model": "default", "ip": "10.10.10.12", "prefix": 24, "gateway": "10.10.10.1", "parent": "eth1", "netmode": "vepa", "sim": "conveyor"},
        {"name": "M340-WATER", "vendor": "schneider", "model": "m340", "ip": "10.10.10.13", "prefix": 24, "gateway": "10.10.10.1", "parent": "eth1", "netmode": "vepa", "sim": "sine"},
        {"name": "IQR-ASSEMBLY", "vendor": "mitsubishi", "model": "iq-r", "ip": "10.10.10.14", "prefix": 24, "gateway": "10.10.10.1", "parent": "eth1", "netmode": "vepa", "sim": "counter"}],
    "links": [{"from": "CLX-PACKAGING", "to": "M340-WATER", "every": 2}, {"from": "S7-1200-LINE1", "to": "IQR-ASSEMBLY", "every": 2},
              {"from": "M340-WATER", "to": "S7-1200-LINE1", "every": 3}]}


async def amain(sim, plcs, links, a):
    sim.loop = asyncio.get_running_loop()
    make_panel(sim, a.panel_bind, a.panel_port)
    if a.scada:
        import scada
        sim.scada = scada.Scada(a.scada)
        sim.scada.sim_url = "http://127.0.0.1:%d/api/state" % a.panel_port
        await sim.scada.start(a.panel_bind, a.scada_port)
    for c in plcs:
        err = await sim.add(c, save=False)
        print("started %s" % c.get("name") if not err else "!! %s: %s" % (c.get("name"), err), flush=True)
    for l in links:
        err = await sim.add_link(l["from"], l["to"], l.get("every", 2), save=False)
        if err:
            print("!! link %s->%s: %s" % (l["from"], l["to"], err))
    while True:
        await asyncio.sleep(0.5)
        for p in sim.plcs:
            p.tick()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config")
    ap.add_argument("--panel-bind", default="127.0.0.1")
    ap.add_argument("--panel-port", type=int, default=8080)
    ap.add_argument("--sample-config", action="store_true")
    ap.add_argument("--scada", help="path to scada.json: also run the SCADA master/HMI")
    ap.add_argument("--scada-port", type=int, default=8090)
    a = ap.parse_args()
    if a.sample_config:
        json.dump(SAMPLE, open("plcs.json", "w"), indent=2)
        print("wrote plcs.json (set 'parent' to your VM adapter name) -> sudo python3 plc_sim.py --config plcs.json")
        return
    cfg = {"plcs": DEFAULT_CFG, "links": []}
    if a.config and os.path.exists(a.config):
        cfg = json.load(open(a.config))
        if isinstance(cfg, list):
            cfg = {"plcs": cfg, "links": []}
    elif a.config:
        cfg = {"plcs": [], "links": []}
    signal.signal(signal.SIGTERM, lambda *x: sys.exit(0))
    cleanup_stale()
    sim = Sim(a.config)
    try:
        asyncio.run(amain(sim, cfg.get("plcs", []), cfg.get("links", []), a))
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        for p in sim.plcs:
            teardown_ns(p)
        if getattr(sim, "scada", None):
            sim.scada.stop()


if __name__ == "__main__":
    sys.modules.setdefault("plc_sim", sys.modules[__name__])   # let scada.py `import plc_sim` get THIS module
    main()
